function scrollPage() {
  window.scrollTo(0, document.body.scrollHeight);
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function clickInbox() {
  const el = document.querySelectorAll("div");
  el.forEach((div) => {
    if (div.textContent === "Inbox") {
      div.click();
    }
  });
}

async function clickAddToSpace() {
  const el = document.querySelectorAll("div");
  for (let i = 0; i < el.length; i++) {
    if (el[i].textContent === "Add to Space") {
      el[i].click();
      await sleep(200);
    }
  }
}

async function RUN() {
  await sleep(5000);
  await clickInbox();
  await sleep(5000);
  console.log("clicking.....");
  await clickAddToSpace();
  await sleep(2000);
  window.location.reload();
}

try {
  RUN();
} catch {
  window.location.reload();
}
