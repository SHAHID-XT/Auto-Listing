function scrollPage() {
  window.scrollTo(0, document.body.scrollHeight);
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function test() {
  await sleep(5000);
  console.log("waited");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function RUN() {
  for (i = 0; i <= 10; i++) {
    scrollPage();
    await sleep(1000);
  }
  const divElements = document.querySelectorAll(
    "div.q-text.qu-ellipsis.qu-whiteSpace--nowrap"
  );

  (async function () {
    for (const element of divElements) {
      if (element.textContent === "Request") {
        try {
          console.log(element);
          await sleep(8000);
          element.click();
          await sleep(8000);
          await clickonPeople();
        } catch {
          await sleep(5000);
        }
      }
    }
  })();
}

async function clickonPeople() {
  console.log("working");
  let boxElements = document.querySelector(
    ".ModalContainerInternal___StyledFlex-s8es4q-2"
  );

  let element = boxElements.querySelectorAll(
    ".ClickWrapper___StyledClickWrapperBox-zoqi4f-0"
  );
  try {
    element[4].click();
  } catch {
    try {
      element[3].click();
    } catch {}
  }

  await sleep(5000);
  let sendelemets = boxElements.querySelectorAll(
    ".q-box.qu-flex--none.qu-display--inline-flex.qu-ml--medium"
  );
  try {
    for (let i = 0; i <= 24; i++) {
      console.log(i);
      sendelemets[i].firstChild.firstChild.firstChild.click();
      await sleep(500);
    }
  } catch {}

  boxElements
    .querySelector(".q-text.qu-ellipsis.qu-whiteSpace--nowrap")
    .click();
}

RUN();
